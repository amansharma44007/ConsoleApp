﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class InputOutput
    {
        internal static void Test()
        {
            string name = "Tony Stark";
            Console.WriteLine(name);
            Console.Write("Enter the name: ");
            name=Console.ReadLine();
            Console.WriteLine($"{name}");
            Console.WriteLine("{0}",name);
            Console.WriteLine(name);
            int x,y;
            x = int.Parse(Console.ReadLine());
            Console.WriteLine(x);
            y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(y);
        }
    }
}
