﻿using System;
namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Aman Sharma");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(i);
            }
            InputOutput.Test();
        }
    }
}
